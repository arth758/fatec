package edu.fatec.sjc.lp2.figures;

public interface Calculable {
	double calcularArea();
}
