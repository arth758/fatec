package edu.fatec.lp2;

public enum FiguraType {
	QUADRADO,
	RETANGULO,
	CIRCULO,
	PARALELOGRAMA,
	TRAPEZIO,
	HEXAGONO,
	TRIANGULO,
	LOSANGO,
	CUBO;
}
