package exercicioFixacao1;

public enum Ocupacao {
	VAZIA, JOG1, JOG2;
}
